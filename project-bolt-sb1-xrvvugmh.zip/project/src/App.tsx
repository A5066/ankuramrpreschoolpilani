import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Classes from './components/Classes';
import Gallery from './components/Gallery';
import Contact from './components/Contact';

function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <Hero />
      <About />
      <Classes />
      <Gallery />
      <Contact />
      
      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                <div className="w-4 h-4 bg-white rounded-full"></div>
              </div>
              <h3 className="text-2xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
                ANKURAM
              </h3>
            </div>
            <p className="text-gray-400 mb-4">Pre School & Day Care</p>
            <div className="flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-8 text-sm text-gray-400">
              <span>Near Power House, Rajgarh Road, Pilani</span>
              <span>Call: 92058-52680</span>
              <span>Email: ankuramplayschool22@gmail.com</span>
            </div>
            <div className="mt-6 pt-6 border-t border-gray-700">
              <p className="text-gray-500 text-sm">
                © 2024 Ankuram Pre School & Day Care. All rights reserved. 
                Where little minds grow big dreams! 🌱
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;