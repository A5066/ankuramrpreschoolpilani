import React from 'react';
import { Baby, Smile, Star, Crown, BookOpen, GraduationCap } from 'lucide-react';

const Classes = () => {
  const classes = [
    {
      name: "Pre-Nursery",
      ageGroup: "1.5 - 2.5 years",
      icon: Baby,
      color: "bg-pink-500",
      bgColor: "bg-pink-50",
      borderColor: "border-pink-200",
      description: "First steps into learning through play and exploration",
      features: ["Sensory play", "Basic motor skills", "Social interaction", "Toilet training support"]
    },
    {
      name: "Nursery",
      ageGroup: "2.5 - 3.5 years",
      icon: Smile,
      color: "bg-green-500",
      bgColor: "bg-green-50",
      borderColor: "border-green-200",
      description: "Building foundation skills through structured activities",
      features: ["Language development", "Number recognition", "Creative arts", "Independence skills"]
    },
    {
      name: "Junior KG",
      ageGroup: "3.5 - 4.5 years",
      icon: Star,
      color: "bg-red-500",
      bgColor: "bg-red-50",
      borderColor: "border-red-200",
      description: "Developing pre-academic skills and creativity",
      features: ["Phonics introduction", "Pattern recognition", "Fine motor skills", "Group activities"]
    },
    {
      name: "Senior KG",
      ageGroup: "4.5 - 5.5 years",
      icon: Crown,
      color: "bg-blue-500",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200",
      description: "Preparing for formal education with advanced concepts",
      features: ["Reading readiness", "Mathematical concepts", "Writing skills", "Problem solving"]
    },
    {
      name: "Class - I",
      ageGroup: "5.5 - 6.5 years",
      icon: BookOpen,
      color: "bg-purple-500",
      bgColor: "bg-purple-50",
      borderColor: "border-purple-200",
      description: "Formal learning begins with structured curriculum",
      features: ["Reading & writing", "Basic mathematics", "Science concepts", "Social skills"]
    },
    {
      name: "Class - II",
      ageGroup: "6.5 - 7.5 years",
      icon: GraduationCap,
      color: "bg-indigo-500",
      bgColor: "bg-indigo-50",
      borderColor: "border-indigo-200",
      description: "Advanced learning with comprehensive development",
      features: ["Advanced literacy", "Mathematical operations", "Scientific thinking", "Leadership skills"]
    }
  ];

  return (
    <section id="classes" className="py-20 bg-gradient-to-br from-yellow-50 to-orange-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-800 mb-6">
            Our <span className="text-orange-600">Classes</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Age-appropriate programs designed to nurture every child's unique potential 
            from their first steps to confident learning.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {classes.map((classItem, index) => (
            <div 
              key={index}
              className={`${classItem.bgColor} ${classItem.borderColor} border-2 rounded-3xl p-6 shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 group`}
            >
              <div className="text-center mb-6">
                <div className={`${classItem.color} w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:animate-bounce`}>
                  <classItem.icon className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-2">{classItem.name}</h3>
                <p className="text-lg text-gray-600 font-medium">{classItem.ageGroup}</p>
              </div>

              <p className="text-gray-700 text-center mb-6">{classItem.description}</p>

              <div className="space-y-3">
                {classItem.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-center space-x-3">
                    <div className={`w-3 h-3 ${classItem.color} rounded-full`}></div>
                    <span className="text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-white rounded-3xl p-8 shadow-xl inline-block">
            <h3 className="text-2xl font-bold text-gray-800 mb-4">Ready to Enroll?</h3>
            <p className="text-gray-600 mb-6">Contact us to schedule a visit and see our facilities</p>
            <button 
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-8 py-4 rounded-full font-bold text-lg transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl"
            >
              Contact Us Today
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Classes;