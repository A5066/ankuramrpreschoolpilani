import React from 'react';
import { BookOpen, Users, Heart, Trophy } from 'lucide-react';

const About = () => {
  const features = [
    {
      icon: BookOpen,
      title: "Material Based Learning",
      description: "Hands-on learning approach using Montessori materials and educational toys",
      color: "bg-blue-500"
    },
    {
      icon: Users,
      title: "Small Class Sizes",
      description: "Individual attention with low teacher-to-student ratios for better learning",
      color: "bg-green-500"
    },
    {
      icon: Heart,
      title: "Caring Environment",
      description: "Nurturing and safe space where children feel loved and supported",
      color: "bg-red-500"
    },
    {
      icon: Trophy,
      title: "Holistic Development",
      description: "Focus on cognitive, social, emotional, and physical development",
      color: "bg-purple-500"
    }
  ];

  return (
    <section id="about" className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-800 mb-6">
            About <span className="text-blue-600">Ankuram</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            At Ankuram Pre School & Day Care, we believe every child is unique and deserves 
            the best foundation for their educational journey. Our approach combines traditional 
            values with modern teaching methods.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 group"
            >
              <div className={`${feature.color} w-16 h-16 rounded-full flex items-center justify-center mb-4 group-hover:animate-bounce`}>
                <feature.icon className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-3xl p-8 lg:p-12 shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold text-gray-800 mb-6">
                Why Choose Ankuram?
              </h3>
              <ul className="space-y-4">
                {[
                  "Experienced and caring teachers",
                  "Safe and hygienic environment",
                  "Age-appropriate curriculum",
                  "Regular parent-teacher communication",
                  "Extracurricular activities",
                  "Nutritious meals and snacks"
                ].map((item, index) => (
                  <li key={index} className="flex items-center space-x-3">
                    <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                    <span className="text-gray-700 font-medium">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="relative">
              <div className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-3xl p-8 text-center transform rotate-3 hover:rotate-0 transition-transform duration-300">
                <h4 className="text-2xl font-bold text-white mb-4">Our Mission</h4>
                <p className="text-white text-lg">
                  To provide a nurturing environment where children can learn, grow, 
                  and develop into confident, creative, and caring individuals.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;