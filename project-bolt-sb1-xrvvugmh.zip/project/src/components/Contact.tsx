import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Users, Heart } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    childAge: '',
    message: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here
    console.log('Form submitted:', formData);
    // You can add actual form submission logic here
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: "Visit Us",
      content: "Near Power House, Rajgarh Road, Pilani",
      color: "bg-red-500"
    },
    {
      icon: Phone,
      title: "Call Us",
      content: "92058-52680",
      color: "bg-green-500"
    },
    {
      icon: Mail,
      title: "Email Us",
      content: "ankuramplayschool22@gmail.com",
      color: "bg-blue-500"
    },
    {
      icon: Clock,
      title: "School Hours",
      content: "Mon - Fri: 8:00 AM - 6:00 PM",
      color: "bg-purple-500"
    }
  ];

  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-green-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-800 mb-6">
            Contact <span className="text-green-600">Us</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Ready to give your child the best start in their educational journey? 
            Get in touch with us today to schedule a visit or learn more about our programs.
          </p>
        </div>

        {/* Admission Open Banner */}
        <div className="mb-16 text-center">
          <div className="inline-block bg-gradient-to-r from-red-500 to-pink-500 text-white px-8 py-4 rounded-full text-xl font-bold animate-pulse shadow-lg">
            🎉 ADMISSIONS OPEN FOR 2024-25 🎉
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            <div className="bg-white rounded-3xl p-8 shadow-xl">
              <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center">Get In Touch</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {contactInfo.map((info, index) => (
                  <div 
                    key={index}
                    className="flex items-start space-x-4 p-4 rounded-xl hover:bg-gray-50 transition-colors duration-300"
                  >
                    <div className={`${info.color} w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0`}>
                      <info.icon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-800 mb-1">{info.title}</h4>
                      <p className="text-gray-600 text-sm">{info.content}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Features Highlight */}
            <div className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-3xl p-8 text-white">
              <h3 className="text-2xl font-bold mb-6 text-center">Why Choose Ankuram?</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { icon: Users, text: "Small Class Sizes" },
                  { icon: Heart, text: "Caring Teachers" },
                  { icon: MapPin, text: "Safe Environment" },
                  { icon: Clock, text: "Flexible Hours" }
                ].map((item, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <item.icon className="h-5 w-5" />
                    <span className="font-medium">{item.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white rounded-3xl p-8 shadow-xl">
            <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center">Send Us a Message</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                    Parent's Name *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                    placeholder="Enter your name"
                  />
                </div>
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                    placeholder="Enter your phone number"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                    placeholder="Enter your email"
                  />
                </div>
                <div>
                  <label htmlFor="childAge" className="block text-sm font-medium text-gray-700 mb-2">
                    Child's Age Group
                  </label>
                  <select
                    id="childAge"
                    name="childAge"
                    value={formData.childAge}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                  >
                    <option value="">Select age group</option>
                    <option value="pre-nursery">Pre-Nursery (1.5-2.5 years)</option>
                    <option value="nursery">Nursery (2.5-3.5 years)</option>
                    <option value="junior-kg">Junior KG (3.5-4.5 years)</option>
                    <option value="senior-kg">Senior KG (4.5-5.5 years)</option>
                    <option value="class-1">Class I (5.5-6.5 years)</option>
                    <option value="class-2">Class II (6.5-7.5 years)</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                  placeholder="Tell us about your child or any questions you have..."
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white px-8 py-4 rounded-xl font-bold text-lg transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                Send Message
              </button>
            </form>

            <div className="mt-8 text-center">
              <p className="text-gray-600 mb-4">Or call us directly:</p>
              <a 
                href="tel:9205852680"
                className="inline-flex items-center space-x-2 bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-full font-bold transition-all duration-300 transform hover:scale-105"
              >
                <Phone className="h-5 w-5" />
                <span>92058-52680</span>
              </a>
            </div>
          </div>
        </div>

        {/* Map Section */}
        <div className="mt-16">
          <div className="bg-white rounded-3xl p-8 shadow-xl">
            <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center">Find Us</h3>
            <div className="text-center">
              <div className="inline-flex items-center space-x-2 text-gray-600 mb-4">
                <MapPin className="h-5 w-5 text-red-500" />
                <span className="font-medium">Near Power House, Rajgarh Road, Pilani</span>
              </div>
              <p className="text-gray-600">
                We're conveniently located in Pilani, easily accessible for families in the area. 
                Contact us to schedule a visit and see our facilities firsthand.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;