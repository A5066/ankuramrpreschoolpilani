import React from 'react';
import { Camera, Play, Palette, Book } from 'lucide-react';

const Gallery = () => {
  const activities = [
    {
      title: "Creative Arts",
      description: "Children expressing themselves through painting, drawing, and crafts",
      icon: Palette,
      color: "bg-pink-500",
      image: "https://images.pexels.com/photos/8613308/pexels-photo-8613308.jpeg?auto=compress&cs=tinysrgb&w=600"
    },
    {
      title: "Story Time",
      description: "Interactive reading sessions that spark imagination and language skills",
      icon: Book,
      color: "bg-blue-500",
      image: "https://images.pexels.com/photos/8613284/pexels-photo-8613284.jpeg?auto=compress&cs=tinysrgb&w=600"
    },
    {
      title: "Play-Based Learning",
      description: "Learning through fun activities and educational games",
      icon: Play,
      color: "bg-green-500",
      image: "https://images.pexels.com/photos/8613333/pexels-photo-8613333.jpeg?auto=compress&cs=tinysrgb&w=600"
    },
    {
      title: "Hands-On Activities",
      description: "Material-based learning with tactile experiences",
      icon: Camera,
      color: "bg-purple-500",
      image: "https://images.pexels.com/photos/8613067/pexels-photo-8613067.jpeg?auto=compress&cs=tinysrgb&w=600"
    }
  ];

  return (
    <section id="gallery" className="py-20 bg-gradient-to-br from-purple-50 to-pink-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-800 mb-6">
            Our <span className="text-purple-600">Gallery</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Take a glimpse into the joyful learning experiences and activities 
            that make Ankuram a special place for children to grow and thrive.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {activities.map((activity, index) => (
            <div 
              key={index}
              className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 group"
            >
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={activity.image} 
                  alt={activity.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/20"></div>
                <div className={`absolute top-4 left-4 ${activity.color} w-12 h-12 rounded-full flex items-center justify-center`}>
                  <activity.icon className="h-6 w-6 text-white" />
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold text-gray-800 mb-3">{activity.title}</h3>
                <p className="text-gray-600">{activity.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Photo Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {[
            "https://images.pexels.com/photos/8613039/pexels-photo-8613039.jpeg?auto=compress&cs=tinysrgb&w=300",
            "https://images.pexels.com/photos/8613204/pexels-photo-8613204.jpeg?auto=compress&cs=tinysrgb&w=300",
            "https://images.pexels.com/photos/8613274/pexels-photo-8613274.jpeg?auto=compress&cs=tinysrgb&w=300",
            "https://images.pexels.com/photos/8613340/pexels-photo-8613340.jpeg?auto=compress&cs=tinysrgb&w=300",
            "https://images.pexels.com/photos/8613092/pexels-photo-8613092.jpeg?auto=compress&cs=tinysrgb&w=300",
            "https://images.pexels.com/photos/8613256/pexels-photo-8613256.jpeg?auto=compress&cs=tinysrgb&w=300",
            "https://images.pexels.com/photos/8613141/pexels-photo-8613141.jpeg?auto=compress&cs=tinysrgb&w=300",
            "https://images.pexels.com/photos/8613226/pexels-photo-8613226.jpeg?auto=compress&cs=tinysrgb&w=300"
          ].map((image, index) => (
            <div 
              key={index}
              className="aspect-square rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
            >
              <img 
                src={image} 
                alt={`Gallery image ${index + 1}`}
                className="w-full h-full object-cover"
              />
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-3xl p-8 text-white inline-block">
            <h3 className="text-2xl font-bold mb-4">Visit Our School</h3>
            <p className="text-lg mb-6">See our facilities and meet our caring teachers in person</p>
            <button 
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-white text-purple-600 px-8 py-4 rounded-full font-bold text-lg transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl"
            >
              Schedule a Visit
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Gallery;