import React from 'react';
import { Star, Heart, Sparkles } from 'lucide-react';

const Hero = () => {
  return (
    <section id="home" className="min-h-screen bg-gradient-to-br from-yellow-400 via-orange-300 to-pink-300 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 animate-float">
          <Star className="h-8 w-8 text-white/30" />
        </div>
        <div className="absolute top-40 right-20 animate-float-delay-1">
          <Heart className="h-6 w-6 text-white/40" />
        </div>
        <div className="absolute bottom-20 left-20 animate-float-delay-2">
          <Sparkles className="h-10 w-10 text-white/30" />
        </div>
        <div className="absolute top-60 right-40 animate-float">
          <div className="w-4 h-4 bg-white/20 rounded-full"></div>
        </div>
        <div className="absolute bottom-40 right-10 animate-float-delay-1">
          <div className="w-6 h-6 bg-white/25 rounded-full"></div>
        </div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20">
        <div className="flex flex-col lg:flex-row items-center justify-between min-h-screen py-12">
          
          {/* Left Content */}
          <div className="flex-1 text-center lg:text-left mb-12 lg:mb-0">
            <div className="mb-8">
              <h1 className="text-6xl lg:text-8xl font-bold mb-4">
                <span className="block text-red-600 animate-bounce-slow">A</span>
                <span className="block text-green-600 animate-bounce-slow" style={{animationDelay: '0.1s'}}>N</span>
                <span className="block text-blue-600 animate-bounce-slow" style={{animationDelay: '0.2s'}}>K</span>
                <span className="block text-purple-600 animate-bounce-slow" style={{animationDelay: '0.3s'}}>U</span>
                <span className="block text-orange-600 animate-bounce-slow" style={{animationDelay: '0.4s'}}>R</span>
                <span className="block text-pink-600 animate-bounce-slow" style={{animationDelay: '0.5s'}}>A</span>
                <span className="block text-teal-600 animate-bounce-slow" style={{animationDelay: '0.6s'}}>M</span>
              </h1>
              <div className="text-2xl lg:text-3xl font-semibold text-white mb-4">
                PRE SCHOOL & DAY CARE
              </div>
            </div>

            <div className="mb-8">
              <div className="inline-block bg-green-500 text-white px-6 py-3 rounded-full text-lg font-bold animate-pulse mb-4">
                Fully Material Based Education
              </div>
              <div className="bg-red-500 text-white px-6 py-3 rounded-full text-lg font-bold animate-pulse">
                ADMISSIONS OPEN FOR 2024-25
              </div>
            </div>

            <p className="text-lg text-gray-800 mb-8 max-w-2xl">
              Where little minds grow big dreams! Our nurturing environment helps children 
              develop through play-based learning, creativity, and exploration.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button 
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-full font-bold text-lg transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl"
              >
                Enroll Now
              </button>
              <button 
                onClick={() => document.getElementById('classes')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-white hover:bg-gray-50 text-blue-600 px-8 py-4 rounded-full font-bold text-lg transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl border-2 border-blue-600"
              >
                View Classes
              </button>
            </div>
          </div>

          {/* Right Content - Animated Tree Logo */}
          <div className="flex-1 flex justify-center lg:justify-end">
            <div className="relative">
              <div className="w-80 h-80 lg:w-96 lg:h-96 relative">
                {/* Tree Trunk */}
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-16 h-32 bg-gradient-to-t from-yellow-700 to-yellow-600 rounded-t-lg"></div>
                
                {/* Tree Leaves */}
                <div className="absolute bottom-24 left-1/2 transform -translate-x-1/2">
                  <div className="relative w-48 h-48">
                    <div className="absolute inset-0 bg-green-500 rounded-full animate-pulse"></div>
                    <div className="absolute top-4 left-4 w-8 h-8 bg-green-400 rounded-full animate-float"></div>
                    <div className="absolute top-8 right-6 w-6 h-6 bg-green-600 rounded-full animate-float-delay-1"></div>
                    <div className="absolute bottom-6 left-8 w-4 h-4 bg-green-300 rounded-full animate-float-delay-2"></div>
                    <div className="absolute bottom-8 right-8 w-5 h-5 bg-green-700 rounded-full animate-float"></div>
                  </div>
                </div>

                {/* Floating Elements Around Tree */}
                <div className="absolute top-10 left-10 animate-float">
                  <div className="w-6 h-6 bg-yellow-400 rounded-full opacity-80"></div>
                </div>
                <div className="absolute top-20 right-8 animate-float-delay-1">
                  <div className="w-4 h-4 bg-pink-400 rounded-full opacity-80"></div>
                </div>
                <div className="absolute bottom-40 left-4 animate-float-delay-2">
                  <div className="w-5 h-5 bg-blue-400 rounded-full opacity-80"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;